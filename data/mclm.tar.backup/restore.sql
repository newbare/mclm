--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.3
-- Dumped by pg_dump version 9.5.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.scenery_node DROP CONSTRAINT fk_scenery_layer_scenery;
ALTER TABLE ONLY public.scenery_node DROP CONSTRAINT fk_scenery_layer_node;
ALTER TABLE ONLY public.postgres_tables DROP CONSTRAINT fk_postgres_tables;
ALTER TABLE ONLY public.node_data DROP CONSTRAINT fk_node_data_layer;
ALTER TABLE ONLY public.node_data DROP CONSTRAINT fk_node_data_filter_item;
ALTER TABLE ONLY public.node_data DROP CONSTRAINT fk_node_data_feicao;
ALTER TABLE ONLY public.dictionary DROP CONSTRAINT fk_dictionary_node;
ALTER TABLE ONLY public.data_panel DROP CONSTRAINT fk_datapanel_datawindow;
ALTER TABLE ONLY public.data_layers DROP CONSTRAINT fk_datalayer_tables;
ALTER TABLE ONLY public.node_data DROP CONSTRAINT fk_datalayer_server;
ALTER TABLE ONLY public.feicao DROP CONSTRAINT fk_datalayer_feature_style;
ALTER TABLE ONLY public.data_layers DROP CONSTRAINT fk_datalayer_feature_style;
ALTER TABLE ONLY public.node_data DROP CONSTRAINT fk_datalayer_data_window;
ALTER TABLE ONLY public.data_field DROP CONSTRAINT fk_datafield_datapanel;
DROP INDEX public.scenery_hndx;
ALTER TABLE ONLY public.service_parameter DROP CONSTRAINT service_parameter_pkey;
ALTER TABLE ONLY public.servers_postgres DROP CONSTRAINT servers_postgres_pkey;
ALTER TABLE ONLY public.servers DROP CONSTRAINT servers_pkey;
ALTER TABLE ONLY public.scenery_node DROP CONSTRAINT scenery_node_pkey;
ALTER TABLE ONLY public.sceneries DROP CONSTRAINT sceneries_pkey;
ALTER TABLE ONLY public.postgres_tables DROP CONSTRAINT postgres_tables_pkey;
ALTER TABLE ONLY public.node_data DROP CONSTRAINT node_data_pkey;
ALTER TABLE ONLY public.filter_item DROP CONSTRAINT filter_item_pkey;
ALTER TABLE ONLY public.feicao DROP CONSTRAINT feicao_pkey;
ALTER TABLE ONLY public.feature_styles DROP CONSTRAINT feature_styles_pkey;
ALTER TABLE ONLY public.dictionary DROP CONSTRAINT dictionary_pkey;
ALTER TABLE ONLY public.data_window DROP CONSTRAINT data_window_pkey;
ALTER TABLE ONLY public.data_panel DROP CONSTRAINT data_panel_pkey;
ALTER TABLE ONLY public.data_layers DROP CONSTRAINT data_layers_pkey;
ALTER TABLE ONLY public.data_field DROP CONSTRAINT data_field_pkey;
ALTER TABLE ONLY public.config DROP CONSTRAINT config_pkey;
SET search_path = topology, pg_catalog;

SET search_path = public, pg_catalog;

ALTER TABLE public.service_parameter ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.servers_postgres ALTER COLUMN id_server DROP DEFAULT;
ALTER TABLE public.servers ALTER COLUMN id_server DROP DEFAULT;
ALTER TABLE public.scenery_node ALTER COLUMN id_scenery_node DROP DEFAULT;
ALTER TABLE public.sceneries ALTER COLUMN id_scenery DROP DEFAULT;
ALTER TABLE public.postgres_tables ALTER COLUMN id_table DROP DEFAULT;
ALTER TABLE public.node_data ALTER COLUMN id_node_data DROP DEFAULT;
ALTER TABLE public.filter_item ALTER COLUMN id_filter_item DROP DEFAULT;
ALTER TABLE public.feicao ALTER COLUMN id_feicao DROP DEFAULT;
ALTER TABLE public.feature_styles ALTER COLUMN id_feature_style DROP DEFAULT;
ALTER TABLE public.dictionary ALTER COLUMN id_dictionary_item DROP DEFAULT;
ALTER TABLE public.data_window ALTER COLUMN id_data_window DROP DEFAULT;
ALTER TABLE public.data_panel ALTER COLUMN id_data_panel DROP DEFAULT;
ALTER TABLE public.data_layers ALTER COLUMN id_data_layer DROP DEFAULT;
ALTER TABLE public.data_field ALTER COLUMN id_data_field DROP DEFAULT;
ALTER TABLE public.config ALTER COLUMN id_config DROP DEFAULT;
DROP SEQUENCE public.service_parameter_id_seq;
DROP TABLE public.service_parameter;
DROP SEQUENCE public.servers_postgres_id_server_seq;
DROP TABLE public.servers_postgres;
DROP SEQUENCE public.servers_id_server_seq;
DROP TABLE public.servers;
DROP SEQUENCE public.scenery_node_id_scenery_node_seq;
DROP TABLE public.scenery_node;
DROP SEQUENCE public.sceneries_id_scenery_seq;
DROP TABLE public.sceneries;
DROP SEQUENCE public.postgres_tables_id_table_seq;
DROP TABLE public.postgres_tables;
DROP SEQUENCE public.node_data_id_node_data_seq;
DROP TABLE public.node_data;
DROP SEQUENCE public.filter_item_id_filter_item_seq;
DROP TABLE public.filter_item;
DROP SEQUENCE public.feicao_id_feicao_seq;
DROP TABLE public.feicao;
DROP SEQUENCE public.feature_styles_id_feature_style_seq;
DROP TABLE public.feature_styles;
DROP SEQUENCE public.dictionary_id_dictionary_item_seq;
DROP TABLE public.dictionary;
DROP SEQUENCE public.data_window_id_data_window_seq;
DROP TABLE public.data_window;
DROP SEQUENCE public.data_panel_id_data_panel_seq;
DROP TABLE public.data_panel;
DROP SEQUENCE public.data_layers_id_data_layer_seq;
DROP TABLE public.data_layers;
DROP SEQUENCE public.data_field_id_data_field_seq;
DROP TABLE public.data_field;
DROP SEQUENCE public.config_id_config_seq;
DROP TABLE public.config;
DROP EXTENSION postgis_topology;
DROP EXTENSION postgis;
DROP EXTENSION hstore;
DROP EXTENSION plpgsql;
DROP SCHEMA topology;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO postgres;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry, geography, and raster spatial types and functions';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE config (
    id_config integer NOT NULL,
    baselayer character varying(250),
    externallayerstolocalserver boolean,
    external_workspace_name character varying(100),
    geoserver_password character varying(50),
    geoserverurl character varying(250),
    geoserver_user character varying(50),
    non_proxy_hosts character varying(250),
    proxy_host character varying(100),
    proxy_password character varying(50),
    proxy_port integer,
    proxy_user character varying(50),
    useproxy boolean,
    map_center character varying(255),
    map_zoom integer,
    query_factor_radius integer,
    shape_file_target_path character varying(100),
    geoserver_database_addr character varying(100),
    geoserver_database_dbname character varying(100),
    geoserver_database_password character varying(100),
    geoserver_database_port integer,
    geoserver_database_user character varying(100),
    routing_database character varying(100),
    routing_password character varying(100),
    routing_port integer,
    routing_server character varying(100),
    routing_user character varying(100),
    apolo_server character varying(100),
    distance_from_route integer,
    servicos_cptec_inpe character varying(100),
    symbol_server_url character varying(250),
    serverhostname character varying(250),
    mapbackgroudcolor character varying(100),
    scandictatstartup boolean
);


ALTER TABLE config OWNER TO postgres;

--
-- Name: config_id_config_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE config_id_config_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE config_id_config_seq OWNER TO postgres;

--
-- Name: config_id_config_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE config_id_config_seq OWNED BY config.id_config;


--
-- Name: data_field; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE data_field (
    id_data_field integer NOT NULL,
    name character varying(250),
    id_data_panel integer,
    caption character varying(250),
    description character varying(250),
    field_order integer,
    fieldtype character varying(15)
);


ALTER TABLE data_field OWNER TO postgres;

--
-- Name: data_field_id_data_field_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE data_field_id_data_field_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE data_field_id_data_field_seq OWNER TO postgres;

--
-- Name: data_field_id_data_field_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE data_field_id_data_field_seq OWNED BY data_field.id_data_field;


--
-- Name: data_layers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE data_layers (
    id_data_layer integer NOT NULL,
    name character varying(250),
    hint character varying(250),
    propertiescolumns character varying(250),
    whereclause character varying(250),
    id_table integer,
    label_column character varying(250),
    id_feature_style integer
);


ALTER TABLE data_layers OWNER TO postgres;

--
-- Name: data_layers_id_data_layer_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE data_layers_id_data_layer_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE data_layers_id_data_layer_seq OWNER TO postgres;

--
-- Name: data_layers_id_data_layer_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE data_layers_id_data_layer_seq OWNED BY data_layers.id_data_layer;


--
-- Name: data_panel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE data_panel (
    id_data_panel integer NOT NULL,
    name character varying(250),
    id_data_window integer,
    panel_order integer
);


ALTER TABLE data_panel OWNER TO postgres;

--
-- Name: data_panel_id_data_panel_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE data_panel_id_data_panel_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE data_panel_id_data_panel_seq OWNER TO postgres;

--
-- Name: data_panel_id_data_panel_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE data_panel_id_data_panel_seq OWNED BY data_panel.id_data_panel;


--
-- Name: data_window; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE data_window (
    id_data_window integer NOT NULL,
    name character varying(250),
    source_database character varying(100),
    source_password character varying(100),
    source_port integer,
    source_server character varying(100),
    source_table character varying(100),
    source_user character varying(100),
    sql_data_acquisition text
);


ALTER TABLE data_window OWNER TO postgres;

--
-- Name: data_window_id_data_window_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE data_window_id_data_window_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE data_window_id_data_window_seq OWNER TO postgres;

--
-- Name: data_window_id_data_window_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE data_window_id_data_window_seq OWNED BY data_window.id_data_window;


--
-- Name: dictionary; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE dictionary (
    id_dictionary_item integer NOT NULL,
    datatype character varying(80),
    originalname character varying(250),
    translatedname character varying(250),
    id_node_data integer,
    description character varying(250),
    visible boolean,
    primary_key boolean,
    index_order integer
);


ALTER TABLE dictionary OWNER TO postgres;

--
-- Name: dictionary_id_dictionary_item_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE dictionary_id_dictionary_item_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE dictionary_id_dictionary_item_seq OWNER TO postgres;

--
-- Name: dictionary_id_dictionary_item_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE dictionary_id_dictionary_item_seq OWNED BY dictionary.id_dictionary_item;


--
-- Name: feature_styles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE feature_styles (
    id_feature_style integer NOT NULL,
    iconanchor character varying(25),
    iconanchorxunits character varying(25),
    iconanchoryunits character varying(25),
    iconopacity character varying,
    iconcolor character varying(25),
    iconrotation character varying(25),
    iconscale character varying(25),
    iconsrc character varying(25),
    textfillcolor character varying(25),
    textfont character varying(25),
    textoffsetx character varying(25),
    textoffsety character varying(25),
    textstrokecolor character varying(25),
    textstrokewidth character varying(25),
    featurestylename character varying,
    polygonfillcolor character varying(25),
    polygonstrokecolor character varying(25),
    polygonstrokewidth character varying(25),
    polygonlinedash character varying(25),
    polygonstrokelinecap character varying(25),
    linefillcolor character varying(25),
    linestrokecolor character varying(25),
    linestrokewidth character varying(25),
    linelinedash character varying(25),
    polygonfillpattern character varying(25),
    polygonfillopacity character varying(25),
    ptrhdist character varying(25),
    ptrheight character varying(25),
    ptrvdist character varying(25),
    ptrwidth character varying(25),
    ptrlength character varying(25)
);


ALTER TABLE feature_styles OWNER TO postgres;

--
-- Name: feature_styles_id_feature_style_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE feature_styles_id_feature_style_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE feature_styles_id_feature_style_seq OWNER TO postgres;

--
-- Name: feature_styles_id_feature_style_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE feature_styles_id_feature_style_seq OWNED BY feature_styles.id_feature_style;


--
-- Name: feicao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE feicao (
    id_feicao integer NOT NULL,
    descricao character varying(250),
    metadados text,
    nome character varying(250),
    geomtype character varying(50),
    id_feature_style integer
);


ALTER TABLE feicao OWNER TO postgres;

--
-- Name: feicao_id_feicao_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE feicao_id_feicao_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE feicao_id_feicao_seq OWNER TO postgres;

--
-- Name: feicao_id_feicao_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE feicao_id_feicao_seq OWNED BY feicao.id_feicao;


--
-- Name: filter_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE filter_item (
    id_filter_item integer NOT NULL,
    description character varying(250),
    filter character varying(250),
    filter_def character varying(250),
    human_filter character varying(250),
    name character varying(250)
);


ALTER TABLE filter_item OWNER TO postgres;

--
-- Name: filter_item_id_filter_item_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE filter_item_id_filter_item_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE filter_item_id_filter_item_seq OWNER TO postgres;

--
-- Name: filter_item_id_filter_item_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE filter_item_id_filter_item_seq OWNED BY filter_item.id_filter_item;


--
-- Name: node_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE node_data (
    id_node_data integer NOT NULL,
    layeralias character varying(150),
    layername character varying(100),
    originalserviceurl character varying(250),
    serviceurl character varying(250),
    id_node_parent integer,
    index_order integer,
    description character varying(250),
    institute character varying(250),
    layertype character varying(5),
    read_only boolean,
    serialid character varying(32),
    id_filter_item integer,
    id_data_layer integer,
    id_data_window integer,
    id_feicao integer,
    cqlfilter character varying(250),
    windowtype character varying(10),
    id_server integer
);


ALTER TABLE node_data OWNER TO postgres;

--
-- Name: node_data_id_node_data_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE node_data_id_node_data_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE node_data_id_node_data_seq OWNER TO postgres;

--
-- Name: node_data_id_node_data_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE node_data_id_node_data_seq OWNED BY node_data.id_node_data;


--
-- Name: postgres_tables; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE postgres_tables (
    id_table integer NOT NULL,
    name character varying(250),
    id_server integer,
    geometrycolumnname character varying(250),
    idcolumnname character varying(250)
);


ALTER TABLE postgres_tables OWNER TO postgres;

--
-- Name: postgres_tables_id_table_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE postgres_tables_id_table_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE postgres_tables_id_table_seq OWNER TO postgres;

--
-- Name: postgres_tables_id_table_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE postgres_tables_id_table_seq OWNED BY postgres_tables.id_table;


--
-- Name: sceneries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE sceneries (
    id_scenery integer NOT NULL,
    base_map character varying(100),
    basemapactive boolean,
    base_server_url character varying(100),
    creation_date timestamp without time zone,
    graticule boolean,
    id_user integer,
    is_public boolean,
    map_center character varying(100),
    scenery_name character varying(100),
    zoom_level integer,
    description text,
    map_bbox character varying(200),
    cpf_user character varying(11),
    map_center_hdms character varying(100),
    user_name character varying(200)
);


ALTER TABLE sceneries OWNER TO postgres;

--
-- Name: sceneries_id_scenery_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sceneries_id_scenery_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sceneries_id_scenery_seq OWNER TO postgres;

--
-- Name: sceneries_id_scenery_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE sceneries_id_scenery_seq OWNED BY sceneries.id_scenery;


--
-- Name: scenery_node; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE scenery_node (
    id_scenery_node integer NOT NULL,
    id_node integer,
    id_node_parent integer,
    index_order integer,
    layeralias character varying(150),
    layerstackindex integer,
    layertype character varying(5),
    selected boolean,
    transparency integer,
    id_layer integer,
    id_scenery integer
);


ALTER TABLE scenery_node OWNER TO postgres;

--
-- Name: scenery_node_id_scenery_node_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE scenery_node_id_scenery_node_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE scenery_node_id_scenery_node_seq OWNER TO postgres;

--
-- Name: scenery_node_id_scenery_node_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE scenery_node_id_scenery_node_seq OWNED BY scenery_node.id_scenery_node;


--
-- Name: servers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE servers (
    id_server integer NOT NULL,
    name character varying(250),
    url character varying(250),
    version character varying(10),
    type character varying(3)
);


ALTER TABLE servers OWNER TO postgres;

--
-- Name: servers_id_server_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE servers_id_server_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE servers_id_server_seq OWNER TO postgres;

--
-- Name: servers_id_server_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE servers_id_server_seq OWNED BY servers.id_server;


--
-- Name: servers_postgres; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE servers_postgres (
    id_server integer NOT NULL,
    name character varying(250),
    serveraddress character varying(250),
    serverdatabase character varying(50),
    serverpassword character varying(50),
    serverport integer,
    serveruser character varying(50),
    type character varying(3)
);


ALTER TABLE servers_postgres OWNER TO postgres;

--
-- Name: servers_postgres_id_server_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE servers_postgres_id_server_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE servers_postgres_id_server_seq OWNER TO postgres;

--
-- Name: servers_postgres_id_server_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE servers_postgres_id_server_seq OWNED BY servers_postgres.id_server;


--
-- Name: service_parameter; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE service_parameter (
    id integer NOT NULL,
    serviceid integer,
    parametertype character(1) DEFAULT 'W'::bpchar NOT NULL,
    parameterkey character varying(255) DEFAULT 'query'::character varying,
    parametervalue text,
    cqlfilter text
);


ALTER TABLE service_parameter OWNER TO postgres;

--
-- Name: service_parameter_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE service_parameter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE service_parameter_id_seq OWNER TO postgres;

--
-- Name: service_parameter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE service_parameter_id_seq OWNED BY service_parameter.id;


--
-- Name: id_config; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY config ALTER COLUMN id_config SET DEFAULT nextval('config_id_config_seq'::regclass);


--
-- Name: id_data_field; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY data_field ALTER COLUMN id_data_field SET DEFAULT nextval('data_field_id_data_field_seq'::regclass);


--
-- Name: id_data_layer; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY data_layers ALTER COLUMN id_data_layer SET DEFAULT nextval('data_layers_id_data_layer_seq'::regclass);


--
-- Name: id_data_panel; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY data_panel ALTER COLUMN id_data_panel SET DEFAULT nextval('data_panel_id_data_panel_seq'::regclass);


--
-- Name: id_data_window; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY data_window ALTER COLUMN id_data_window SET DEFAULT nextval('data_window_id_data_window_seq'::regclass);


--
-- Name: id_dictionary_item; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY dictionary ALTER COLUMN id_dictionary_item SET DEFAULT nextval('dictionary_id_dictionary_item_seq'::regclass);


--
-- Name: id_feature_style; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY feature_styles ALTER COLUMN id_feature_style SET DEFAULT nextval('feature_styles_id_feature_style_seq'::regclass);


--
-- Name: id_feicao; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY feicao ALTER COLUMN id_feicao SET DEFAULT nextval('feicao_id_feicao_seq'::regclass);


--
-- Name: id_filter_item; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filter_item ALTER COLUMN id_filter_item SET DEFAULT nextval('filter_item_id_filter_item_seq'::regclass);


--
-- Name: id_node_data; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY node_data ALTER COLUMN id_node_data SET DEFAULT nextval('node_data_id_node_data_seq'::regclass);


--
-- Name: id_table; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY postgres_tables ALTER COLUMN id_table SET DEFAULT nextval('postgres_tables_id_table_seq'::regclass);


--
-- Name: id_scenery; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sceneries ALTER COLUMN id_scenery SET DEFAULT nextval('sceneries_id_scenery_seq'::regclass);


--
-- Name: id_scenery_node; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY scenery_node ALTER COLUMN id_scenery_node SET DEFAULT nextval('scenery_node_id_scenery_node_seq'::regclass);


--
-- Name: id_server; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY servers ALTER COLUMN id_server SET DEFAULT nextval('servers_id_server_seq'::regclass);


--
-- Name: id_server; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY servers_postgres ALTER COLUMN id_server SET DEFAULT nextval('servers_postgres_id_server_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY service_parameter ALTER COLUMN id SET DEFAULT nextval('service_parameter_id_seq'::regclass);


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY config (id_config, baselayer, externallayerstolocalserver, external_workspace_name, geoserver_password, geoserverurl, geoserver_user, non_proxy_hosts, proxy_host, proxy_password, proxy_port, proxy_user, useproxy, map_center, map_zoom, query_factor_radius, shape_file_target_path, geoserver_database_addr, geoserver_database_dbname, geoserver_database_password, geoserver_database_port, geoserver_database_user, routing_database, routing_password, routing_port, routing_server, routing_user, apolo_server, distance_from_route, servicos_cptec_inpe, symbol_server_url, serverhostname, mapbackgroudcolor, scandictatstartup) FROM stdin;
\.
COPY config (id_config, baselayer, externallayerstolocalserver, external_workspace_name, geoserver_password, geoserverurl, geoserver_user, non_proxy_hosts, proxy_host, proxy_password, proxy_port, proxy_user, useproxy, map_center, map_zoom, query_factor_radius, shape_file_target_path, geoserver_database_addr, geoserver_database_dbname, geoserver_database_password, geoserver_database_port, geoserver_database_user, routing_database, routing_password, routing_port, routing_server, routing_user, apolo_server, distance_from_route, servicos_cptec_inpe, symbol_server_url, serverhostname, mapbackgroudcolor, scandictatstartup) FROM '$$PATH$$/3798.dat';

--
-- Name: config_id_config_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('config_id_config_seq', 1, false);


--
-- Data for Name: data_field; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY data_field (id_data_field, name, id_data_panel, caption, description, field_order, fieldtype) FROM stdin;
\.
COPY data_field (id_data_field, name, id_data_panel, caption, description, field_order, fieldtype) FROM '$$PATH$$/3800.dat';

--
-- Name: data_field_id_data_field_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('data_field_id_data_field_seq', 124, true);


--
-- Data for Name: data_layers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY data_layers (id_data_layer, name, hint, propertiescolumns, whereclause, id_table, label_column, id_feature_style) FROM stdin;
\.
COPY data_layers (id_data_layer, name, hint, propertiescolumns, whereclause, id_table, label_column, id_feature_style) FROM '$$PATH$$/3802.dat';

--
-- Name: data_layers_id_data_layer_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('data_layers_id_data_layer_seq', 34, true);


--
-- Data for Name: data_panel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY data_panel (id_data_panel, name, id_data_window, panel_order) FROM stdin;
\.
COPY data_panel (id_data_panel, name, id_data_window, panel_order) FROM '$$PATH$$/3804.dat';

--
-- Name: data_panel_id_data_panel_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('data_panel_id_data_panel_seq', 44, true);


--
-- Data for Name: data_window; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY data_window (id_data_window, name, source_database, source_password, source_port, source_server, source_table, source_user, sql_data_acquisition) FROM stdin;
\.
COPY data_window (id_data_window, name, source_database, source_password, source_port, source_server, source_table, source_user, sql_data_acquisition) FROM '$$PATH$$/3806.dat';

--
-- Name: data_window_id_data_window_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('data_window_id_data_window_seq', 9, true);


--
-- Data for Name: dictionary; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY dictionary (id_dictionary_item, datatype, originalname, translatedname, id_node_data, description, visible, primary_key, index_order) FROM stdin;
\.
COPY dictionary (id_dictionary_item, datatype, originalname, translatedname, id_node_data, description, visible, primary_key, index_order) FROM '$$PATH$$/3808.dat';

--
-- Name: dictionary_id_dictionary_item_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('dictionary_id_dictionary_item_seq', 266517, true);


--
-- Data for Name: feature_styles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY feature_styles (id_feature_style, iconanchor, iconanchorxunits, iconanchoryunits, iconopacity, iconcolor, iconrotation, iconscale, iconsrc, textfillcolor, textfont, textoffsetx, textoffsety, textstrokecolor, textstrokewidth, featurestylename, polygonfillcolor, polygonstrokecolor, polygonstrokewidth, polygonlinedash, polygonstrokelinecap, linefillcolor, linestrokecolor, linestrokewidth, linelinedash, polygonfillpattern, polygonfillopacity, ptrhdist, ptrheight, ptrvdist, ptrwidth, ptrlength) FROM stdin;
\.
COPY feature_styles (id_feature_style, iconanchor, iconanchorxunits, iconanchoryunits, iconopacity, iconcolor, iconrotation, iconscale, iconsrc, textfillcolor, textfont, textoffsetx, textoffsety, textstrokecolor, textstrokewidth, featurestylename, polygonfillcolor, polygonstrokecolor, polygonstrokewidth, polygonlinedash, polygonstrokelinecap, linefillcolor, linestrokecolor, linestrokewidth, linelinedash, polygonfillpattern, polygonfillopacity, ptrhdist, ptrheight, ptrvdist, ptrwidth, ptrlength) FROM '$$PATH$$/3810.dat';

--
-- Name: feature_styles_id_feature_style_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('feature_styles_id_feature_style_seq', 22, true);


--
-- Data for Name: feicao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY feicao (id_feicao, descricao, metadados, nome, geomtype, id_feature_style) FROM stdin;
\.
COPY feicao (id_feicao, descricao, metadados, nome, geomtype, id_feature_style) FROM '$$PATH$$/3812.dat';

--
-- Name: feicao_id_feicao_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('feicao_id_feicao_seq', 113, true);


--
-- Data for Name: filter_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY filter_item (id_filter_item, description, filter, filter_def, human_filter, name) FROM stdin;
\.
COPY filter_item (id_filter_item, description, filter, filter_def, human_filter, name) FROM '$$PATH$$/3814.dat';

--
-- Name: filter_item_id_filter_item_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('filter_item_id_filter_item_seq', 1, false);


--
-- Data for Name: node_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY node_data (id_node_data, layeralias, layername, originalserviceurl, serviceurl, id_node_parent, index_order, description, institute, layertype, read_only, serialid, id_filter_item, id_data_layer, id_data_window, id_feicao, cqlfilter, windowtype, id_server) FROM stdin;
\.
COPY node_data (id_node_data, layeralias, layername, originalserviceurl, serviceurl, id_node_parent, index_order, description, institute, layertype, read_only, serialid, id_filter_item, id_data_layer, id_data_window, id_feicao, cqlfilter, windowtype, id_server) FROM '$$PATH$$/3816.dat';

--
-- Name: node_data_id_node_data_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('node_data_id_node_data_seq', 904744, true);


--
-- Data for Name: postgres_tables; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY postgres_tables (id_table, name, id_server, geometrycolumnname, idcolumnname) FROM stdin;
\.
COPY postgres_tables (id_table, name, id_server, geometrycolumnname, idcolumnname) FROM '$$PATH$$/3818.dat';

--
-- Name: postgres_tables_id_table_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('postgres_tables_id_table_seq', 11, true);


--
-- Data for Name: sceneries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sceneries (id_scenery, base_map, basemapactive, base_server_url, creation_date, graticule, id_user, is_public, map_center, scenery_name, zoom_level, description, map_bbox, cpf_user, map_center_hdms, user_name) FROM stdin;
\.
COPY sceneries (id_scenery, base_map, basemapactive, base_server_url, creation_date, graticule, id_user, is_public, map_center, scenery_name, zoom_level, description, map_bbox, cpf_user, map_center_hdms, user_name) FROM '$$PATH$$/3820.dat';

--
-- Name: sceneries_id_scenery_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sceneries_id_scenery_seq', 107, true);


--
-- Data for Name: scenery_node; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY scenery_node (id_scenery_node, id_node, id_node_parent, index_order, layeralias, layerstackindex, layertype, selected, transparency, id_layer, id_scenery) FROM stdin;
\.
COPY scenery_node (id_scenery_node, id_node, id_node_parent, index_order, layeralias, layerstackindex, layertype, selected, transparency, id_layer, id_scenery) FROM '$$PATH$$/3822.dat';

--
-- Name: scenery_node_id_scenery_node_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('scenery_node_id_scenery_node_seq', 108, true);


--
-- Data for Name: servers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY servers (id_server, name, url, version, type) FROM stdin;
\.
COPY servers (id_server, name, url, version, type) FROM '$$PATH$$/3824.dat';

--
-- Name: servers_id_server_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('servers_id_server_seq', 38, true);


--
-- Data for Name: servers_postgres; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY servers_postgres (id_server, name, serveraddress, serverdatabase, serverpassword, serverport, serveruser, type) FROM stdin;
\.
COPY servers_postgres (id_server, name, serveraddress, serverdatabase, serverpassword, serverport, serveruser, type) FROM '$$PATH$$/3826.dat';

--
-- Name: servers_postgres_id_server_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('servers_postgres_id_server_seq', 6, true);


--
-- Data for Name: service_parameter; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY service_parameter (id, serviceid, parametertype, parameterkey, parametervalue, cqlfilter) FROM stdin;
\.
COPY service_parameter (id, serviceid, parametertype, parameterkey, parametervalue, cqlfilter) FROM '$$PATH$$/3828.dat';

--
-- Name: service_parameter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('service_parameter_id_seq', 724, true);


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY spatial_ref_sys  FROM stdin;
\.
COPY spatial_ref_sys  FROM '$$PATH$$/3609.dat';

SET search_path = topology, pg_catalog;

--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology  FROM stdin;
\.
COPY topology  FROM '$$PATH$$/3610.dat';

--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY layer  FROM stdin;
\.
COPY layer  FROM '$$PATH$$/3611.dat';

SET search_path = public, pg_catalog;

--
-- Name: config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY config
    ADD CONSTRAINT config_pkey PRIMARY KEY (id_config);


--
-- Name: data_field_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY data_field
    ADD CONSTRAINT data_field_pkey PRIMARY KEY (id_data_field);


--
-- Name: data_layers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY data_layers
    ADD CONSTRAINT data_layers_pkey PRIMARY KEY (id_data_layer);


--
-- Name: data_panel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY data_panel
    ADD CONSTRAINT data_panel_pkey PRIMARY KEY (id_data_panel);


--
-- Name: data_window_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY data_window
    ADD CONSTRAINT data_window_pkey PRIMARY KEY (id_data_window);


--
-- Name: dictionary_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY dictionary
    ADD CONSTRAINT dictionary_pkey PRIMARY KEY (id_dictionary_item);


--
-- Name: feature_styles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY feature_styles
    ADD CONSTRAINT feature_styles_pkey PRIMARY KEY (id_feature_style);


--
-- Name: feicao_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY feicao
    ADD CONSTRAINT feicao_pkey PRIMARY KEY (id_feicao);


--
-- Name: filter_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY filter_item
    ADD CONSTRAINT filter_item_pkey PRIMARY KEY (id_filter_item);


--
-- Name: node_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY node_data
    ADD CONSTRAINT node_data_pkey PRIMARY KEY (id_node_data);


--
-- Name: postgres_tables_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY postgres_tables
    ADD CONSTRAINT postgres_tables_pkey PRIMARY KEY (id_table);


--
-- Name: sceneries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sceneries
    ADD CONSTRAINT sceneries_pkey PRIMARY KEY (id_scenery);


--
-- Name: scenery_node_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY scenery_node
    ADD CONSTRAINT scenery_node_pkey PRIMARY KEY (id_scenery_node);


--
-- Name: servers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY servers
    ADD CONSTRAINT servers_pkey PRIMARY KEY (id_server);


--
-- Name: servers_postgres_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY servers_postgres
    ADD CONSTRAINT servers_postgres_pkey PRIMARY KEY (id_server);


--
-- Name: service_parameter_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY service_parameter
    ADD CONSTRAINT service_parameter_pkey PRIMARY KEY (id);


--
-- Name: scenery_hndx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX scenery_hndx ON sceneries USING btree (id_scenery);


--
-- Name: fk_datafield_datapanel; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY data_field
    ADD CONSTRAINT fk_datafield_datapanel FOREIGN KEY (id_data_panel) REFERENCES data_panel(id_data_panel);


--
-- Name: fk_datalayer_data_window; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY node_data
    ADD CONSTRAINT fk_datalayer_data_window FOREIGN KEY (id_data_window) REFERENCES data_window(id_data_window);


--
-- Name: fk_datalayer_feature_style; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY data_layers
    ADD CONSTRAINT fk_datalayer_feature_style FOREIGN KEY (id_feature_style) REFERENCES feature_styles(id_feature_style);


--
-- Name: fk_datalayer_feature_style; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY feicao
    ADD CONSTRAINT fk_datalayer_feature_style FOREIGN KEY (id_feature_style) REFERENCES feature_styles(id_feature_style);


--
-- Name: fk_datalayer_server; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY node_data
    ADD CONSTRAINT fk_datalayer_server FOREIGN KEY (id_server) REFERENCES servers(id_server);


--
-- Name: fk_datalayer_tables; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY data_layers
    ADD CONSTRAINT fk_datalayer_tables FOREIGN KEY (id_table) REFERENCES postgres_tables(id_table);


--
-- Name: fk_datapanel_datawindow; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY data_panel
    ADD CONSTRAINT fk_datapanel_datawindow FOREIGN KEY (id_data_window) REFERENCES data_window(id_data_window);


--
-- Name: fk_dictionary_node; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY dictionary
    ADD CONSTRAINT fk_dictionary_node FOREIGN KEY (id_node_data) REFERENCES node_data(id_node_data);


--
-- Name: fk_node_data_feicao; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY node_data
    ADD CONSTRAINT fk_node_data_feicao FOREIGN KEY (id_feicao) REFERENCES feicao(id_feicao);


--
-- Name: fk_node_data_filter_item; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY node_data
    ADD CONSTRAINT fk_node_data_filter_item FOREIGN KEY (id_filter_item) REFERENCES filter_item(id_filter_item);


--
-- Name: fk_node_data_layer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY node_data
    ADD CONSTRAINT fk_node_data_layer FOREIGN KEY (id_data_layer) REFERENCES data_layers(id_data_layer);


--
-- Name: fk_postgres_tables; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY postgres_tables
    ADD CONSTRAINT fk_postgres_tables FOREIGN KEY (id_server) REFERENCES servers_postgres(id_server);


--
-- Name: fk_scenery_layer_node; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY scenery_node
    ADD CONSTRAINT fk_scenery_layer_node FOREIGN KEY (id_layer) REFERENCES node_data(id_node_data);


--
-- Name: fk_scenery_layer_scenery; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY scenery_node
    ADD CONSTRAINT fk_scenery_layer_scenery FOREIGN KEY (id_scenery) REFERENCES sceneries(id_scenery);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

